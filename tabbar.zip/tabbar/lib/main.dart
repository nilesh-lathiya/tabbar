import 'package:flutter/material.dart';
import 'package:tabbar/drower.dart';
import 'package:tabbar/tbfst.dart';

void main() {
  runApp(MaterialApp(
    home:drower(),
  ));
}

